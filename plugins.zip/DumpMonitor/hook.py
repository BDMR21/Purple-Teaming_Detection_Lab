# hook.py - Point d'entrée du plugin Caldera
import asyncio
import os
from app.objects.secondclass.c_fact import Fact
from .dump_monitor_svc import DumpMonitorService


# Métadonnées du plugin
name = "DumpMonitor"  # Nom unique du plugin (un seul mot)
description = "Surveillance des dumps LSASS et injection de credentials dans les facts basic"
address = None  # Pas d'interface web dédiée pour ce plugin


async def enable(services):
    """
    Fonction appelée au démarrage de Caldera pour activer le plugin.
    Elle initialise le service de surveillance de dumps LSASS.
    """
    # Récupération des services nécessaires
    data_svc = services.get('data_svc')
    knowledge_svc = services.get('knowledge_svc')
    # Dossier à surveiller pour les fichiers .dmp (peut être modifié au besoin)
    watch_directory = os.path.expanduser("~/MEGA/test")
    # Instanciation du service de surveillance
    monitor_service = DumpMonitorService(watch_directory, data_svc, knowledge_svc)
    # Démarrage de la tâche asynchrone de veille (sans bloquer le démarrage)
    asyncio.create_task(monitor_service.watch_dumps())
